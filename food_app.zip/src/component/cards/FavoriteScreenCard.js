import React, { useState } from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native";
import { bgColor, colors } from "../../assets/color";
import PlusBtnSvg from "../../assets/svg/PlusBtnSvg";
import HeartSvg from "../../assets/svg/HeartSvg";

const FavoriteScreenCard = ({ image, productName, price, weight }) => {
  const [touch, setTouch] = useState(false);
  const [icon, setIcon] = useState(false);
  return (
    <View style={styles.container}>
      <Image
        // source={image ? image : require("../../assets/images/food.jpg")}
        source={image ? image : ''}
        style={styles.image}
        resizeMode="contain"
      />
      <View style={styles.textContainer}>
        <View style={styles.heartIconContainer}>
          <View style={styles.wishListIcon}>
            <TouchableOpacity style={styles.heartIcon}>
              <HeartSvg strokeColor={"red"} fillColor={'red'}/>
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.infoContainer}>
          <View style={styles.productInfo}>
            <Text style={styles.productName}>
              {productName ? productName : "Vegetable salad"}
            </Text>
          </View>
        </View>
        <View style={styles.infoContainer}>
          <View style={styles.priceContainer}>
            <Text style={styles.title}>{price ? price : "$10.99"}</Text>
            <Text style={styles.line}>|</Text>
            <Text style={styles.line}>{weight ? weight + "g" : "200g"}</Text>
          </View>
          <TouchableOpacity style={styles.icon}>
            <PlusBtnSvg />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: 160,
    height: 199,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.white,
    borderRadius: 10,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    position: "relative",
    marginHorizontal: 5,
  },
  image: {
    width: 160,
    height: 199,
  },
  wishListIcon: {
    marginLeft: "auto",
    marginBottom: 10,
  },
  heartIconContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    paddingHorizontal: 14,
    marginBottom: 4,
  },
  infoContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    paddingHorizontal: 14,
    marginBottom: 4,
    backgroundColor: "rgba(255, 255, 255, 0.7)",
  },

  textContainer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 5,
    // backgroundColor: "rgba(255, 255, 255, 0.7)",
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
    marginBottom: 6,
    width: "100%",
  },
  priceContainer: {
    flexDirection: "row",
  },
  title: {
    fontSize: 14,
    color: colors.mainColor,
    fontWeight: "bold",
  },
  productName: {
    color: colors.textColor,
    opacity: 0.3,
  },
  line: {
    color: colors.textColor,
    marginLeft: 5,
    opacity: 0.3,
  },
  heartIcon: {
    padding: 5,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
  },
  icon: {
    backgroundColor: bgColor.iconbgColor,
    padding: 5,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
  },
  productInfo: {
    flex: 1,
  },
});

export default FavoriteScreenCard;
