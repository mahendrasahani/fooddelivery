import React, { Component } from "react";
import { View, Text, StyleSheet } from "react-native";
import { bgColor, color, colors } from "../../assets/color";

const ScrollViewCard = ({ heading1, heading2, subheading, text, backgroundColor }) => {
  return (
    <View style={[styles.container, { backgroundColor }]}>
      <View style={styles.textContainer}>
        <Text style={styles.heading}>
          {heading1 ? heading1 : "Order Burger combo"}
        </Text>
        <Text style={styles.heading}>
          {heading2 ? heading2 : "Order Burger combo"}
        </Text>
        <Text style={styles.subheading}>{subheading ? subheading : 'and Save up to'}</Text>
        <Text style={styles.text}>{text ? text : "50%"}</Text>
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: 320,
    height: 193,
    justifyContent: "center",
    alignItems: "flex-start",
    backgroundColor: bgColor.scrollCard,
    borderRadius: 10,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    borderRadius: 10,
    position: "relative",
    padding: 5,
  },
  textContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    justifyContent: "center",
    alignItems: "flex-start",
    borderRadius: 10,
    padding: 10,
  },
  heading: {
    fontSize: 22,
    fontWeight: "bold",
    color: colors.darkBlue,
    textAlign: "center",
  },
  subheading: {
    fontSize: 14,
    color: colors.mainColor,
    textAlign: "center",
    marginTop: 5,
  },
  text: {
    fontSize: 54,
    color: color.percentage,
    textAlign: "center",
    marginTop: 10,
    marginBottom: 10,
    fontWeight: "500",
  },
});
export default ScrollViewCard;
