import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { colors } from '../../assets/color';
 
const MenuCategoryCard = ({image, categoryName}) => {
    return (
        <View style={styles.container}>
            <Image 
                // source={image ? image : require('../../assets/images/food.jpg')}
                source={image ? image : ''}
                style={styles.image}
                resizeMode="contain"
            />
            <View style={styles.textContainer}>
                <Text style={styles.title}>{categoryName ? categoryName : 'CategoryName'}</Text>
            </View>
        </View>
    );
}; 

// small menu items card --------------------------------------------------------------------------------------------------------------------------------------------------------

export const SmallMenuCard = ({name}) =>{
    return (
        <View style={name ? styles.smallContainer : styles.ActiveSmallContainer}>
            <View style={styles.smalltextContainer}>
                <Text style={name ? styles.text : styles.smallTitle}>{name ? name : 'menu name'}</Text>
            </View>
        </View>
    );
};

export const productCard = ({name}) =>{
    return (
        <View style={name? styles.productContainer : styles.activeProductContainer}>
            <View style={styles.producttextContainer}>
                <Text style={name? styles.text : styles.productTitle}>{name? name : 'product name'}</Text>
            </View>
        </View>
    );
}
 

const styles = StyleSheet.create({
    container: {
        width: 160,
        height: 160,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: colors.white,
        borderRadius: 10,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.2,
        position: 'relative',
        marginHorizontal: 5
    },
    image: {
        width: 90, 
        height: 90,
    },
    textContainer: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        margin: 8,
        borderBottomLeftRadius: 10,
    },
    title: {
        fontSize: 16,
        color: colors.black,
    },
  
    smallContainer: { 
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: colors.white,
        borderRadius: 10,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.2,
        position: 'relative',
        marginHorizontal: 5,
        padding: 5,
        borderWidth: 1,
        borderColor: colors.primary,
    },
    ActiveSmallContainer: { 
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: colors.white,
        borderRadius: 10,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.2,
        position: 'relative',
        marginHorizontal: 5,
        padding: 5,
    },
    
    smalltextContainer: {
        bottom: 0,
        left: 0,
        margin: 8,
    },
    smallTitle:{
        fontSize: 12,
        color: colors.textColor,
        fontWeight: 'bold',
    },
    text:{
        fontSize: 12,
        color: colors.primary,
        fontWeight: 'bold',
    }
     
}); 
export default MenuCategoryCard;




