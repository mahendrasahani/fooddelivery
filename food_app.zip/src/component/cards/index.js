import CategoryCard from "./categoryCard";

export default {CategoryCard}