import React from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity, Dimensions } from "react-native";
import { bgColor, colors } from "../../assets/color";
import PlusBtnSvg from "../../assets/svg/PlusBtnSvg";
import HeartSvg from "../../assets/svg/HeartSvg";
import MinusSvg from "../../assets/svg/MinusSvg"; 

const ProductMenuCard = ({ image, product, calorie, weight, urlprice, id, des, quantity, price, addToCart}) => {
  // console.warn(price);
  return (
    <View style={styles.container}>
      <View style={styles.imageContainer}>
        <Image
          source={image ? image : require("../../assets/images/food.jpg")}
          style={styles.image}
        />
      </View>
      <View style={styles.textContainer}>
        <View style={styles.heartIconContainer}>
          <TouchableOpacity>
            <HeartSvg style={styles.icon} strokeColor={"gray"} />
          </TouchableOpacity>
        </View>
        <View style={styles.infoContainer}>
          <Text style={styles.title}>
            {product ? product : "Creamy Chicken Alfredo"}
          </Text>
          <Text style={styles.subTitle}>
            {des ? des + "kcal" : "Lettuce, tomatoes, cucumbers,"}
          </Text>
          <Text style={styles.subTitle}>
            {calorie ? calorie + "kcal" : "110 kcal "} -{" "}
            {weight ? weight + "g" : "200g"}
          </Text>
        </View>
        <View style={styles.priceContainer}>
          <Text style={styles.price}>${price}</Text>
          <View style={styles.quantityContainer}>
            {/* <TouchableOpacity onPress={() => addToCart(id, "decrease")}>
              <MinusSvg />
            </TouchableOpacity>
            <Text style={styles.quantity}>{quantity}</Text>
            <TouchableOpacity onPress={() => addToCart(id, "increase")}>
              <PlusBtnSvg />
            </TouchableOpacity> */}
            <View stytle={styles.addToCartButtonContainer}>
              <TouchableOpacity>
                <Text>
                  + Add
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    width: 335,
    height: 160,
    backgroundColor: colors.white,
    borderRadius: 10,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    // marginHorizontal: 5,
  },
  imageContainer: {
    flex: 2,
    backgroundColor: bgColor.iconbgColor,
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10,
  },
  image: {
    width: "100%",
    height: "100%",
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10,
  },
  textContainer: {
    flex: 2,
    padding: 10,
    justifyContent: "space-between",
  },
  heartIconContainer: {
    position: "absolute",
    top: 10,
    right: 10,
    zIndex: 1,
  },
  infoContainer: {
    marginTop: 20,
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    color: colors.mainColor,
  },
  subTitle: {
    fontSize: 14,
    color: colors.textColor,
    // marginTop: 5,
  },
  priceContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    // marginTop: -10,
  },
  price: {
    fontSize: 16,
    fontWeight: "bold",
    color: colors.primary,
  },
  quantityContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  buttonText: {
    fontSize: 20,
    fontWeight: "bold",
    paddingHorizontal: 10,
  },
  quantity: {
    fontSize: 16,
    fontWeight: "bold",
    color: colors.textColor,
    textAlign: "center",
    marginHorizontal: 10,
  },
  plusIconContainer: {
    backgroundColor: bgColor.iconbgColor,
    padding: 5,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
  },
  icon: {
    width: 24,
    height: 24,
  },
  addToCartButton: {
    backgroundColor: colors.primary,
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  addToCartButtonContainer: {
    position: "absolute",
    bottom: 16,
    left: 16,
    right: 16,
    backgroundColor: '#000',
    padding: 15,
    alignItems: "center",
    borderRadius: 16,
  },
});

export default ProductMenuCard;
