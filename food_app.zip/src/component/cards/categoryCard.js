 
import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { colors } from '../../assets/color';

// create a component
const CategoryCard = ({image, name}) => {
    return (
        <View style={styles.container}>
            <Image 
                // source={image ? image : require('../../assets/images/food.jpg')}
                source={image ? image : null}
                style={styles.image}
                resizeMode="contain"
            />
            <View style={styles.textContainer}>
                <Text style={styles.title}>{name ? name : 'CategoryName'}</Text>
            </View>
        </View>
    );
}; 
const styles = StyleSheet.create({
    container: {
        width: 90,
        height: 90,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: colors.white,
        borderRadius: 10,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.2,
        position: 'relative',
        marginHorizontal: 5
    },
    image: {
        width: "100%", 
        height: "100%",
    },
    textContainer: {
        position: 'absolute',
        bottom: 0,
        left: 0, 
        paddingVertical: 5,
        marginLeft: 8, 
        borderBottomLeftRadius: 10,
    },
    title: {
        fontSize: 14,
        color: colors.black,
        fontWeight: 'bold', 
    }
}); 
export default CategoryCard;
