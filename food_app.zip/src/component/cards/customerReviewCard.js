import React, { useState } from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native";
import { bgColor, colors } from "../../assets/color";
import PlusBtnSvg from "../../assets/svg/PlusBtnSvg";
import { useNavigation } from "@react-navigation/native";

const CostumerReviewCard = ({ image, userName, date, reviewMessage }) => {
  const navigation = useNavigation()
  const [touch, setTouch] = useState(false);
  const [icon, setIcon] = useState(false);
  return (
    <View style={styles.container}>
      {/* <TouchableOpacity onPress={() => navigation.navigate('CostumerReviewScreen')}> */}
        <View style={styles.textContainer}>
          <View style={styles.infoContainer}>
            <Image source={image ? image : null} style={styles.image} />
            <View style={styles.textWrapper}>
              <View style={{ flexDirection: "column" }}>
                <Text style={styles.title}>
                  {userName ? userName : "Caesar with Chicken"}
                </Text>
                <Text style={styles.price}></Text>
                {/* <View style={styles.price}>

              </View> */}
              </View>
              <View
                style={{
                  flexDirection: "column",
                  alignItems: "flex-end",
                  marginLeft: 20,
                }}
              >
                <Text style={styles.date}>{date ? date : "Aug 23, 2023"}</Text>
                <TouchableOpacity>
                  <Text style={styles.price}>Reply</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      {/* </TouchableOpacity> */}
      <View style={styles.textContainer}>
        <View style={styles.weightContainer}>
          <Text style={styles.line}>
            ____________________________________________
          </Text>
        </View>
      </View>
      <View style={styles.textContainer}>
        <View style={styles.weightContainer}>
          <Text style={styles.reviewMessage}>
            {reviewMessage
              ? reviewMessage
              : "Absolutely loved the food! The flavors were so vibrant and the presentation was top-notch. Can't wait to order again!"}
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    // flex: 1,
    width: 320,
    height: 158,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.white,
    borderRadius: 10,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    position: "relative",
    marginHorizontal: 5,
  },
  infoContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 4,
  },
  textContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingLeft: 14,
    paddingRight: 14,
  },
  textWrapper: {
    marginLeft: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  priceContainer: {
    flexDirection: "row",
  },
  title: {
    fontSize: 14,
    color: colors.mainColor,
    fontWeight: "bold",
  },
  date: {
    fontSize: 14,
    color: colors.textColor,
    fontWeight: "bold",
  },
  price: {
    fontSize: 14,
    color: colors.primary,
    marginTop: 4,
  },
  icon: {
    backgroundColor: bgColor.iconbgColor,
    padding: 5,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
  },
  image: {
    width: 50,
    height: 50,
    borderRadius: 50,
    backgroundColor: colors.bgColor,
  },
  weightContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    marginBottom: 4,
  },
  line: {
    color: colors.textColor,
    marginLeft: 5,
    opacity: 0.3,
  },
  reviewMessage: {
    color: colors.textColor,
    marginLeft: 5,
    opacity: 0.3,
    fonSize: 18,
  },
});

export default CostumerReviewCard;
