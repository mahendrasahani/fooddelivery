import React from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Platform,
  TouchableOpacity,
} from "react-native";
import { color as themeColors, colors } from "../../assets/color";
import UserSvg from "../../assets/svg/UserSvg";
import CartSvg from "../../assets/svg/CartSvg";
import GoBackSvg from "../../assets/svg/GoBackSvg";
import { useNavigation } from "@react-navigation/native";

const Header = ({ price, username, pageName, icon = false }) => {
  const navigation = useNavigation();
  return (
    <SafeAreaView style={styles.header}>
      <View style={styles.container}>
        {pageName ? (
          <View style={styles.goBackSvg}>
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <GoBackSvg style={styles.image} />
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.userImage}>
            <UserSvg style={styles.image} />
          </View>
        )}
        <View style={styles.nameContainer}>
          {pageName ? (
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <Text style={styles.text}>{pageName}</Text>
            </TouchableOpacity>
          ) : (
            <Text style={styles.text}>{username ? username : ""}</Text>
          )}
        </View>
      </View>
      {icon && (
        <View style={styles.price}>
          <View style={styles.iconBackGround}>
            <View style={styles.priceContainer}>
              <Text style={styles.priceText}>
                {price ? "$" + price : "$20"}
              </Text>
            </View>
            <TouchableOpacity>
              <CartSvg style={styles.image} />
            </TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  header: {
    width: "100%",
    height: Platform.OS === "ios" ? 60 : 60,
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: Platform.OS === "ios" ? 0 : 40,
    borderRadius: 10,
    flexDirection: "row",
    paddingHorizontal: 10,
    backgroundColor: themeColors.white,
  },
  price: {
    flexDirection: "row",
    alignItems: "center",
  },
  container: {
    flexDirection: "row",
    alignItems: "center",
  },
  userImage: {
    justifyContent: "center",
    alignItems: "center",
    width: 40,
    height: 40,
    borderRadius: 50,
    backgroundColor: "#748BA0",
  },
  goBackSvg: {
    justifyContent: "center",
    alignItems: "center",
    width: 40,
    height: 40,
    borderRadius: 50,
  },
  priceContainer: {
    justifyContent: "center",
    alignItems: "center",
    width: 30,
    height: 30,
    borderRadius: 50,
    backgroundColor: colors.primary,
  },
  iconBackGround: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    marginLeft: 10,
  },
  text: {
    fontSize: 14,
    fontWeight: "bold",
    marginLeft: 8,
    color: colors.black,
    textAlign: "center",
  },
  priceText: {
    fontSize: 10,
    fontWeight: "bold",
    color: colors.white,
    textAlign: "center",
  },
  image: {
    width: 20,
    height: 20,
  },
  nameContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Header;
