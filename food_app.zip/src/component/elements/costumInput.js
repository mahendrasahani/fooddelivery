import React from "react";
import { View, TextInput, TouchableOpacity, Text } from "react-native";
import { colors } from "../../assets/color";
import KeySvg from "../../assets/svg/KeySvg";
import MailSvg from "../../assets/svg/MailSvg";
import UserSvg from "../../assets/svg/UserSvg";
import InputCheckSvg from "../../assets/svg/InputCheckSvg";
import EyeOffSvg from "../../assets/svg/EyeOffSvg";
import SearchSvg from "../../assets/svg/SearchSvg";
 
const InputField = ({
  placeholder,
  containerStyle,
  secureTextEntry,
  keyboardType,
  checkIcon,
  eyeOffIcon = false,
  onChangeText,
  blurOnSubmit,
  label,
  value,
  icon,
  type,
  innerRef,
  maxLength,
}) => {
  return (
    <View
      style={{
        padding: 5,
        width: "100%",
        borderColor: "#DBE9F5",
        justifyContent: "center",
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "#E9F3F6",
        borderRadius: 10,
        ...containerStyle,
      }}
    >
      <View
        style={{
          width: 40,
          height: 40,
          backgroundColor:colors.primary,
          borderRadius: 10,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {type === "cvv" && <KeySvg />}
        {type === "email" && <MailSvg />}
        {type === "password" && <KeySvg />}
        {type === "location" && <MapSvg />}
        {type === "username" && <UserSvg />}
        {type === "date" && <CalendarSvg />}
        {type === "promocode" && <TagSvg />}
        {type === "phone" && <SmartphoneSvg />}
        {type === "creditCard" && <CreditCardSvg />}
        {type === "expirationDate" && <CalendarSvg />}
        {type === "search" && <SearchSvg />}
      </View>
      <TextInput
        style={{
          flex: 1,
          height: "100%",
          width: "100%",
          flexDirection: "row",
          justifyContent: "space-between",
          fontSize: 16,
          marginLeft: 14,

        }}
        keyboardType={keyboardType}
        placeholder={placeholder}
        placeholderTextColor={"#A7AFB7"}
        secureTextEntry={secureTextEntry}
        onChangeText={onChangeText}
        value={value}
        ref={innerRef}
        blurOnSubmit={blurOnSubmit}
        maxLength={maxLength}
      />
      {label && (
        <View
          style={{
            position: "absolute",
            top: -12,
            left: 10,
            paddingHorizontal: 10,
            backgroundColor: colors.white,
          }}
        >
          <Text
            style={{
              fontSize: 12,
              textTransform: "uppercase",
              color: colors.textColor,
              lineHeight: 12 * 1.7,
            }}
          >
            {label}
          </Text>
        </View>
      )}
      {checkIcon && (
        <View style={{ paddingHorizontal: 20 }}>
          <InputCheckSvg />
        </View>
      )}
      {eyeOffIcon && (
        <TouchableOpacity style={{ paddingHorizontal: 20 }}>
          <EyeOffSvg />
        </TouchableOpacity>
      )}
      {icon && (
        <TouchableOpacity
          style={{
            paddingHorizontal: 20,
            paddingVertical: 10,
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          {icon}
        </TouchableOpacity>
      )}
    </View>
  );
};
export default InputField;