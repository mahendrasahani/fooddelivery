import React, { useState, useEffect, useRef } from "react";
import { View, StyleSheet, SafeAreaView, ScrollView, Dimensions, Platform, TouchableOpacity, ActivityIndicator, } from "react-native";
import { bgColor, color, colors } from "../assets/color";
import Header from "../component/elements/header";
import ApiUrl from "../../navigation/Api";
import FavoriteScreenCard from "../component/cards/FavoriteScreenCard";

const { width } = Dimensions.get("window");

const FavoriteScreen = ({ navigation }) => {
    const scrollViewRef = useRef();
    const [isLoading, setIsLoading] = useState(false);




    // here we go to logical part 

    const fetchData = async () => {
        try {
            const response = await fetch(ApiUrl + '/test');
            const responseData = await response.json();
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };


    useEffect(() => {
        const loadData = async () => {
            setIsLoading(true);
            await fetchData();
            setIsLoading(false);
        };
        loadData();
    }, [navigation]);

    return (
        <SafeAreaView style={styles.container}>
            {isLoading ? (
                <ActivityIndicator size="large" color={colors.primary} />
            ) : (
                <>
                    <View style={styles.topContainer}>
                        <Header pageName={'Favorite'} icon={true} />
                    </View>
                    <ScrollView style={styles.scontainer}>
                        <View style={styles.categorycard}>
                            <TouchableOpacity>
                                <FavoriteScreenCard />
                            </TouchableOpacity>
                            <TouchableOpacity>
                                <FavoriteScreenCard />
                            </TouchableOpacity>
                        </View>
                        <View style={styles.categorycard}>
                            <TouchableOpacity>
                                <FavoriteScreenCard />
                            </TouchableOpacity>
                            <TouchableOpacity>
                                <FavoriteScreenCard />
                            </TouchableOpacity>
                        </View>
                    </ScrollView>
                </>
            )}
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.bodybackground,
        justifyContent: "center",
        paddingTop: Platform.OS === "ios" ? 0 : 0,
    },
    scontainer: {
        marginTop: Platform.OS === "ios" ? 0 : 10,
        marginBottom: 70
    },
    topContainer: {
        paddingRight: Platform.OS === "ios" ? 0 : 10,
        paddingLeft: Platform.OS === "ios" ? 0 : 10,
        backgroundColor: 'none',
    },
    bottomContainer: {
        justifyContent: "space-between",
        alignItems: "center",
        marginTop: 5,
        flexDirection: "row",
        paddingRight: 50,
    },
    searchContainer: {
        flex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: 10,
        backgroundColor: bgColor.bodybackground,
        alignItems: "center",
        width: "100%",
    },
    categorycard: {
        paddingHorizontal: 10,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 10,
    },
});

export default FavoriteScreen;
