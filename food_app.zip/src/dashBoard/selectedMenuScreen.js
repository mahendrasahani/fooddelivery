import React, { useState, useEffect, useRef } from "react";
import { View, StyleSheet, SafeAreaView, ScrollView, Dimensions, Text, TouchableOpacity, ActivityIndicator, Platform, Modal} from "react-native";
import { bgColor, colors } from "../assets/color";
import Header from "../component/elements/header";
import InputField from "../component/elements/costumInput";
import FilterSvg from "../assets/svg/FilterSvg";
import MenuCategoryCard, {
  SmallMenuCard,
} from "../component/cards/menuCategoryCard";
import ProductMenuCard from "../component/cards/productMenuCard";
import ApiUrl from "../../navigation/Api";
import * as Animatable from "react-native-animatable";

const { width, height } = Dimensions.get("window");

const CategoryScreen = ({ navigation }) => {
  const scrollViewRef = useRef();
  const [isLoading, setIsLoading] = useState(false);
  const fetchData = async () => {
    try {
      const response = await fetch(ApiUrl + "/test");
      const responseData = await response.json();
      // Process the data as needed
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await fetchData();
      setIsLoading(false);
    };
    loadData();
  }, [navigation]);

  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const [animation, setAnimation] = useState("fadeInUp");
  const [showAddToCartButton, setShowAddToCartButton] = useState(false);
  const [products, setProducts] = useState([
    {
      id: 1,
      product: "Tandoori Chicken",
      calorie: "110",
      urlprice: 17.99,
      quantity: 1,
      price: 17.99,
    },
    {
      id: 2,
      product: "Chicken Tikka",
      calorie: "110",
      urlprice: 13.49,
      quantity: 1,
      price: 13.49,
    },
    {
      id: 3,
      product: "Pan-Seared Duck",
      calorie: "110",
      urlprice: 6.99,
      quantity: 1,
      price: 6.99,
    },
    {
      id: 4,
      product: "Pan-Seared Duck",
      calorie: "110",
      urlprice: 6.99,
      quantity: 1,
      price: 6.99,
    },
    {
      id: 5,
      product: "Pan-Seared Duck",
      calorie: "110",
      urlprice: 6.99,
      quantity: 1,
      price: 6.99,
    },
  ]);
  const [smallCard, setSmallCard] = useState([
    {
      id: 1,
      name: "Salads",
    },
    {
      id: 2,
      name: "Pasta",
    },
    {
      id: 3,
      name: "Hot meals",
    },
    {
      id: 4,
      name: "Fish",
    },
    {
      id: 5,
      name: "First courses",
    },
  ]);
  const addToCart = (id, action) => {
    setProducts((prevProducts) => {
      return prevProducts.map((product) => {
        if (product.id === id) {
          let newQuantity = product.quantity;
          if (action === "increase") {
            newQuantity += 1;
            setShowAddToCartButton(true);
          } else if (action === "decrease") {
            newQuantity = newQuantity > 1 ? newQuantity - 1 : 1;
            setShowAddToCartButton(newQuantity > 1);
            setAnimation("fadeOutDown");
          }
          return {
            ...product,
            quantity: newQuantity,
            price: newQuantity * product.urlprice,
          };
        }
        return product;
      });
    });
  };
  const onAddToCartPress = async () => {
    setModalVisible(true);
    setLoading(true);
    setModalMessage("");
    try {
      const response = await fetch(ApiUrl + "/test");
      const responseData = await response.json();
      if (response) {
        setLoading(false);
        setModalMessage("Your product has been added to the cart.");
      }
    } catch (error) {
      setLoading(false);
      setModalMessage("Error adding product to cart.");
      console.error("Error fetching data:", error);
    }
  };
  const getCateGory = (item) => {
    console.warn(item);
  };

  return (
    <SafeAreaView style={styles.container}>
      {isLoading ? (
        <ActivityIndicator size={"large"} color={colors.primary} />
      ) : (
        <>
          <View style={styles.topContainer}>
            <Header username={'Shashank Shekhar'} icon={true}/>
          </View>
          <View style={styles.bottomContainer}>
            <View style={styles.searchContainer}>
              <InputField
                type={"search"}
                placeholder={"Search ..."}
                style={styles.inputField}
              />
              <TouchableOpacity style={styles.filter}>
                <FilterSvg />
              </TouchableOpacity>
            </View>
          </View>
          <ScrollView style={styles.scontainer}>
            <View style={styles.smallCardContainer}>
              <ScrollView
                ref={scrollViewRef}
                horizontal
                scrollEventThrottle={16}
                style={styles.scrollView}
              >
                <View style={styles.categoryCard}>
                  {smallCard.map((item) => (
                    <View key={item.id}>
                      <TouchableOpacity onPress={() => getCateGory(item)}>
                        <SmallMenuCard name={item.name} />
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              </ScrollView>
            </View>
            <View style={styles.productSection}>
              <View style={styles.cardContainer}>
                <Text style={styles.productCardText}>Recommended for you</Text>
              </View>
              <ScrollView ref={scrollViewRef} style={styles.scrollView}>
                {products.map((product) => (
                  <View style={styles.productCardContainer} key={product.id}>
                    <TouchableOpacity
                      onPress={() => navigation.navigate("ViewProduct")}
                    >
                      <ProductMenuCard
                        id={product.id}
                        product={product.product}
                        calorie={product.calorie}
                        urlprice={product.urlprice}
                        quantity={product.quantity}
                        price={product.price}
                        addToCart={addToCart}
                      />
                    </TouchableOpacity>
                  </View>
                ))}
              </ScrollView>
            </View>
          </ScrollView>
          {showAddToCartButton && (
            <Animatable.View
              style={styles.addToCartButtonContainer}
              animation="fadeInUp"
            >
              <TouchableOpacity
                style={styles.addToCartButton}
                onPress={onAddToCartPress}
              >
                <Text style={styles.addToCartButtonText}>Add to Cart</Text>
              </TouchableOpacity>
            </Animatable.View>
          )}
          <Modal
            transparent={true}
            animationType="slide"
            visible={modalVisible}
            onRequestClose={() => setModalVisible(false)}
          >
            <View style={styles.modalContainer}>
              <View style={styles.modalContent}>
                <View style={styles.modalTextContainer}>
                  {loading ? (
                    <ActivityIndicator size="large" color={colors.primary} />
                  ) : (
                    <Text>{modalMessage}</Text>
                  )}
                </View>
                <TouchableOpacity
                  style={styles.modalButtonContainer}
                  onPress={() => setModalVisible(false)}
                >
                  <View style={styles.modalButton}>
                    <Text style={styles.modalButtonText}>Close</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        </>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bodybackground,
    justifyContent: "center",
  },
  scontainer: {
    flex: 1,
    marginTop: Platform.OS === "ios" ? 0 : 10,
  },
  scrollView: {
    flex: 1,
    // marginHorizontal: 5,
  },
  topContainer: {
    paddingHorizontal: Platform.OS === "ios" ? 0 : 10,
    backgroundColor: "none",
  },
  bottomContainer: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  searchContainer: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    backgroundColor: bgColor.bodybackground,
    alignItems: "center",
    width: "100%",
  },
  inputField: {
    flex: 1,
    backgroundColor: colors.white,
    borderRadius: 10,
    fontSize: 16,
  },
  filter: {
    padding: 10,
    height: 50,
    borderRadius: 5,
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 10,
  },
  smallCardContainer: {
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 10,
  },
  categoryCard: {
    flexDirection: "row",
    padding: 10,
  },
  productSection: {
    marginTop: 10,
    width: "100%",
  },
  cardContainer: {
    paddingHorizontal: 20,
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
    marginBottom: 14,
  },
  productCardContainer: {
    width: width,
    paddingVertical: 5,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1,
  },
  productCardText: {
    fontSize: 18,
    color: colors.mainColor,
    fontWeight: "500",
  },
  addToCartButtonContainer: {
    position: "absolute",
    bottom: 16,
    left: 16,
    right: 16,
    backgroundColor: colors.primary,
    padding: 15,
    alignItems: "center",
    borderRadius: 16,
  },
  addToCartButton: {
    backgroundColor: colors.primary,
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },

  addToCartButtonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: "bold",
  },
  modalButtonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: "bold",
  },
  modalButton: {
    backgroundColor: colors.primary,
  },
  modalButtonContainer: {
    backgroundColor: colors.primary,
    padding: 10,
    alignItems: "center",
    borderRadius: 16,
  },
  modalTextContainer: {
    backgroundColor: colors.white,
    padding: 10,
    alignItems: "center",
    borderRadius: 16,
  },
  modalContainer: {
    ...StyleSheet.absoluteFillObject,
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.5)",
    marginTop: 10,
  },
  modalContent: {
    width: 300,
    padding: 20,
    backgroundColor: colors.white,
    borderRadius: 18,
  },
});

export default CategoryScreen;
