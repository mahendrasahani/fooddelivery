import React, { useState, useEffect, useRef } from "react";
import { View, Text, StyleSheet, SafeAreaView, Image, ScrollView, Dimensions, Animated, Platform, TouchableOpacity, ActivityIndicator} from "react-native";
import { color, colors } from "../assets/color";
import Header from "../component/elements/header";
import ViewAllSvg from "../assets/svg/ViewAllSvg";
import CategoryCard from "../component/cards/categoryCard";
import ProductCard from "../component/cards/productCard";
import CostumerReviewCard from "../component/cards/customerReviewCard";
import ApiUrl from "../../navigation/Api";

const { width } = Dimensions.get("window");

const DashBoardScreen = ({ navigation }) => {
  const [activeDot, setActiveDot] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const imageScrollViewRef = useRef();
  const scrollViewRef = useRef();
  const intervalRef = useRef();
  const [isLoading, setIsLoading] = useState(false);

  const fetchData = async () => {
    try {
      const response = await fetch(ApiUrl + "/test");
      const responseData = await response.json();
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await fetchData();
      setIsLoading(false);
    };
    loadData();
  }, [navigation]);

  const images = [
    {
      uri: require("../assets/images/food.jpg"),
      heading: "Order salmon steak today",
      subheading: "and Save up to",
      text: "35%",
    },
    {
      uri: require("../assets/images/food.jpg"),
      heading: "Craft Your Perfect Order",
      subheading: "Customize your cravings and place orders effortlessly.",
    },
    {
      uri: require("../assets/images/food.jpg"),
      heading: "Taste the Delivered Magic",
      subheading: "Enjoy the convenience of doorstep culinary delights.",
    },
    {
      uri: require("../assets/images/food.jpg"),
      heading: "Taste the Delivered Magic",
      subheading: "Enjoy the convenience of doorstep culinary delights.",
    },
    {
      uri: require("../assets/images/food.jpg"),
      heading: "Taste the Delivered Magic",
      subheading: "Enjoy the convenience of doorstep culinary delights.",
    },
  ];

  const dotScales = useRef(images.map(() => new Animated.Value(1))).current;

  const handleScroll = (event) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const currentPage = Math.round(scrollPosition / width);
    setActiveDot(currentPage);
    fadeInText();
    animateDotScale(currentPage);
  };

  const fadeInText = () => {
    fadeAnim.setValue(0);
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  };

  const animateDotScale = (currentPage) => {
    dotScales.forEach((dotScale, index) => {
      Animated.spring(dotScale, {
        toValue: index === currentPage ? 1.5 : 1,
        useNativeDriver: true,
        friction: 4,
      }).start();
    });
  };

  useEffect(() => {
    fadeInText();
  }, [activeDot, isLoading]);

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      let nextIndex = (activeDot + 1) % images.length;
      imageScrollViewRef.current.scrollTo({
        x: nextIndex * width,
        animated: true,
      });
      setActiveDot(nextIndex);
    }, 3000);

    return () => clearInterval(intervalRef.current);
  }, [activeDot, isLoading]);

  return (
    <SafeAreaView style={styles.container}>
      {isLoading ? (
        <ActivityIndicator size="large" color={colors.primary} />
      ) : (
        <>
          <View style={styles.topContainer}>
            <Header username={"Shashank Shekhar"} icon={true} />
          </View>
          <ScrollView style={styles.scontainer}>
            <ScrollView
              ref={imageScrollViewRef}
              horizontal
              pagingEnabled
              onScroll={handleScroll}
              showsHorizontalScrollIndicator={false}
              scrollEventThrottle={16}
              style={styles.scrollView}
            >
              {images.map((image, index) => (
                <View key={index} style={styles.imageContainer}>
                  <Image style={styles.image} source={image.uri} />
                  <Animated.View
                    style={[styles.textContainer, { opacity: fadeAnim }]}
                  >
                    <Text style={styles.heading}>
                      {image.heading.split(" ").slice(0, 2).join(" ")}
                    </Text>
                    <Text style={styles.heading}>
                      {image.heading.split(" ").slice(2).join(" ")}
                    </Text>
                    <Text style={styles.subheading}>{image.subheading}</Text>
                    {image.text && (
                      <Text style={styles.text}>{image.text}</Text>
                    )}
                  </Animated.View>
                </View>
              ))}
            </ScrollView>
            <View style={styles.indicatorContainer}>
              {images.map((_, dotIndex) => (
                <Animated.View
                  key={dotIndex}
                  style={[
                    styles.dot,
                    dotIndex === activeDot
                      ? styles.dotActive
                      : styles.dotInactive,
                    {
                      transform: [
                        {
                          scale: dotScales[dotIndex],
                        },
                      ],
                    },
                  ]}
                />
              ))}
            </View>
            <View style={styles.bottomContainer}>
              <Text style={styles.bottomText}>We offer</Text>
              <View style={styles.bottomIconContainer}>
                <TouchableOpacity onPress={() => navigation.navigate("Menu")}>
                  <ViewAllSvg />
                </TouchableOpacity>
              </View>
            </View>
            <ScrollView
              ref={scrollViewRef}
              horizontal
              scrollEventThrottle={16}
              style={styles.scrollView}
            >
              <View style={styles.categorycard}>
                <TouchableOpacity onPress={() => navigation.navigate("SelectedMenuScreen")}>
                  <CategoryCard name={"meat"} />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => navigation.navigate("SelectedMenuScreen")}>
                  <CategoryCard name={"Salads"} />
                </TouchableOpacity>
                <TouchableOpacity>
                  <CategoryCard name={"Pasta"} />
                </TouchableOpacity>
                <TouchableOpacity>
                  <CategoryCard name={"Pasta"} />
                </TouchableOpacity>
                <TouchableOpacity>
                  <CategoryCard name={"Pasta"} />
                </TouchableOpacity>
              </View>
            </ScrollView>
            <View style={styles.CardContainer}>
              <Text style={styles.productCardText}>Recommended for you</Text>
            </View>
            <ScrollView
              ref={scrollViewRef}
              horizontal
              scrollEventThrottle={16}
              style={styles.scrollView}
            >
              <View style={styles.productCardContainer}>
                <ProductCard weight={"200"} />
                <ProductCard weight={"200"} />
                <ProductCard weight={"200"} />
                <ProductCard weight={"200"} />
              </View>
            </ScrollView>
            <View style={{ marginBottom: 20 }}>
              <View style={styles.bottomContainer}>
                <Text style={styles.productCardText}>
                  Our Happy clients say
                </Text>
                <View style={styles.bottomIconContainer}>
                  <TouchableOpacity>
                    <ViewAllSvg />
                  </TouchableOpacity>
                </View>
              </View>
              <ScrollView
                ref={scrollViewRef}
                horizontal
                scrollEventThrottle={16}
                style={styles.scrollView}
              >
                <TouchableOpacity onPress={() => navigation.navigate("CostumerReviewScreen")} >
                  <CostumerReviewCard />
                </TouchableOpacity>
                <CostumerReviewCard />
                <CostumerReviewCard />
                <CostumerReviewCard />
              </ScrollView>
            </View>
          </ScrollView>
        </>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bodybackground,
    justifyContent: "center",
    paddingTop: Platform.OS === "ios" ? 0 : 0,
    // marginBottom: 50
  },
  scontainer: {
    marginTop: Platform.OS === "ios" ? 0 : 10,
    marginBottom: 60,
  },
  imageContainer: {
    width: width,
    height: 250,
    justifyContent: "center",
    alignItems: "center",
  },
  image: {
    width: width,
    height: 250,
    resizeMode: "cover",
  },
  indicatorContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 10,
    marginTop: -20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.bgColor,
    marginHorizontal: 4,
  },
  textContainer: {
    position: "absolute",
    top: 50,
    left: 0,
    right: 0,
    justifyContent: "center",
    alignItems: "flex-start",
    borderRadius: 10,
    padding: 10,
  },
  heading: {
    fontSize: 28,
    fontWeight: "bold",
    color: colors.darkBlue,
    textAlign: "center",
  },
  subheading: {
    fontSize: 14,
    color: colors.mainColor,
    textAlign: "center",
    marginTop: 5,
  },
  text: {
    fontSize: 54,
    color: color.warning,
    textAlign: "center",
    marginTop: 10,
    marginBottom: 10,
    fontWeight: "500",
  },
  topContainer: {
    paddingRight: Platform.OS === "ios" ? 0 : 10,
    paddingLeft: Platform.OS === "ios" ? 0 : 10,
  },
  dotActive: {
    width: 6,
    height: 12,
    borderRadius: 4,
    backgroundColor: "rgba(255, 255, 255, 0.7)",
  },
  dotInactive: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.textColor,
  },
  bottomContainer: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 5,
    flexDirection: "row",
  },
  bottomText: {
    fontSize: 16,
    color: colors.mainColor,
    fontWeight: "500",
  },
  productCardText: {
    fontSize: 18,
    color: colors.mainColor,
    fontWeight: "500",
  },

  CardContainer: {
    paddingHorizontal: 20,
    justifyContent: "space-between",
    alignItems: "center",
    // marginTop: 5,
    flexDirection: "row",
  },

  bottomTextViewAll: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: "500",
  },
  bottomIconContainer: {
    justifyContent: "center",
    alignItems: "center",
  },
  categorycard: {
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  productCardContainer: {
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
});

export default DashBoardScreen;
