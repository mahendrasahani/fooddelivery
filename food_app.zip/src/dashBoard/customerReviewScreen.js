import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Image,
  ScrollView,
  Dimensions,
  Animated,
  Platform,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { color, colors } from "../assets/color";
import Header from "../component/elements/header"; 
import CostumerReviewCard from "../component/cards/customerReviewCard";
import ApiUrl from "../../navigation/Api";

const { width } = Dimensions.get("window");

const CostumerReviewScreen = ({ navigation }) => {
  const [activeDot, setActiveDot] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current; 
  const [isLoading, setIsLoading] = useState(false);

  const fetchData = async () => {
    try {
      const response = await fetch(ApiUrl + "/test");
      const responseData = await response.json();
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await fetchData();
      setIsLoading(false);
    };
    loadData();
  }, [navigation]); 
  return (
    <SafeAreaView style={styles.container}>
      {isLoading ? (
        <ActivityIndicator size="large" color={colors.primary} />
      ) : (
        <>
          <View style={styles.topContainer}>
            <Header pageName={"Reviews"} icon={true}/>
          </View>
          <ScrollView style={styles.scontainer}>
            <View style={{ marginBottom: 20 }}>
              {/* <View style={styles.bottomContainer}>
                <Text style={styles.productCardText}>
                  Our Happy clients say
                </Text>
              </View> */}
              <View style={styles.CardContainer}>
                <CostumerReviewCard />
              </View>
              <View style={styles.CardContainer}>
                <CostumerReviewCard />
              </View>
              <View style={styles.CardContainer}>
                <CostumerReviewCard />
              </View>
              <View style={styles.CardContainer}>
                <CostumerReviewCard />
              </View>
              <View style={styles.CardContainer}>
                <CostumerReviewCard />
              </View>
              <View style={styles.CardContainer}>
                <CostumerReviewCard />
              </View>
              <View style={styles.CardContainer}>
                <CostumerReviewCard />
              </View>
            </View>
          </ScrollView>
        </>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bodybackground,
    justifyContent: "center",
    paddingTop: Platform.OS === "ios" ? 0 : 0,
    // marginBottom: 50
  },
  scontainer: {
    marginTop: Platform.OS === "ios" ? 0 : 10,
    // marginBottom: 60,
  },
  topContainer: {
    paddingRight: Platform.OS === "ios" ? 0 : 10,
    paddingLeft: Platform.OS === "ios" ? 0 : 10,
  },
  bottomContainer: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    justifyContent: "space-between",
    alignItems: "center",
    // marginTop: 5,
    flexDirection: "row",
    marginLeft: 7,
  }, 
  productCardText: {
    fontSize: 18,
    color: colors.mainColor,
    fontWeight: "500",
  },
  CardContainer: {
    paddingHorizontal: 20,
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 7,
    flexDirection: "row",
  },
});

export default CostumerReviewScreen;
