import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Dimensions,
  Platform,
  ActivityIndicator,
  SafeAreaView,
} from "react-native";
import ApiUrl from "../../navigation/Api";
import { color, colors } from "../assets/color";
import Header from "../component/elements/header";
import MinusSvg from "../assets/svg/MinusSvg";
import PlusSvg from "../assets/svg/PlusSvg";

const { width } = Dimensions.get("window");

const ViewProductScreen = ({ navigation }) => {
  const [activeDot, setActiveDot] = useState(0);
  const imageScrollViewRef = useRef();
  const [isLoading, setIsLoading] = useState(false);

  const fetchData = async () => {
    try {
      const response = await fetch(ApiUrl + "/test");
      const responseData = await response.json();
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await fetchData();
      setIsLoading(false);
    };
    loadData();
  }, [navigation]);

  const images = [
    {
      uri: require("../assets/images/food.jpg"),
      heading: "Order salmon steak today",
      subheading: "and Save up to",
      text: "35%",
    },
    {
      uri: require("../assets/images/food.jpg"),
      heading: "Taste the Delivered Magic",
      subheading: "Enjoy the convenience of doorstep culinary delights.",
    },
    {
      uri: require("../assets/images/food.jpg"),
      heading: "Taste the Delivered Magic",
      subheading: "Enjoy the convenience of doorstep culinary delights.",
    },
  ];

  const handleScroll = (event) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const currentPage = Math.round(scrollPosition / width);
    setActiveDot(currentPage);
  };

  const handleImagePress = (index) => {
    setActiveDot(index);
    imageScrollViewRef.current.scrollTo({ x: width * index, animated: true });
  };

  const [quantity, setQuantity] = useState(1);
  const [price, setPrice] = useState(50);
  const unitPrice = 50;
  const count = (action) => {
    setQuantity((prevQuantity) => {
      let newQuantity;
      if (action === "increase") {
        newQuantity = prevQuantity + 1;
      } else if (action === "decrease") {
        newQuantity = prevQuantity > 1 ? prevQuantity - 1 : 1;
      } else {
        newQuantity = prevQuantity;
      }
      setPrice(newQuantity * unitPrice);
      return newQuantity;
    });
  };

  const addToCart = () => {
    console.warn(quantity, price);
  };

  return (
    <SafeAreaView style={styles.scontainer}>
      <View style={styles.container}>
        <View style={styles.topContainer}>
          <Header pageName={"Product Name"} price={20} icon={true}/>
        </View>
        <>
          <ScrollView style={styles.scontainer}>
            <ScrollView
              ref={imageScrollViewRef}
              horizontal
              pagingEnabled
              onScroll={handleScroll}
              showsHorizontalScrollIndicator={false}
              scrollEventThrottle={16}
              contentContainerStyle={styles.scrollView}
            >
              {images.map((image, index) => (
                <View key={index} style={styles.imageContainer}>
                  <Image style={styles.image} source={image.uri} />
                </View>
              ))}
            </ScrollView>
            <ScrollView>
              <View style={styles.smallImageContainer}>
                <View style={styles.someImageContainer}>
                  {images.map((image, index) => (
                    <TouchableOpacity
                      key={index}
                      onPress={() => handleImagePress(index)}
                    >
                      <View style={styles.smallImageInner}>
                        <Image style={styles.smallImage} source={image.uri} />
                      </View>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </ScrollView>
            <View style={styles.CardContainer}>
              <View style={styles.textContainer}>
                <Text style={styles.heading}>Vegetable salad</Text>
                <Text style={styles.subheading}> 110 kcal - 200g</Text>
              </View>
              {/* <View style={styles.textContainer}>
                <Text style={styles.subheading}> 110 kcal - 200g</Text>
              </View> */}
            </View>
            <View style={styles.CardContainer}>
              <View style={styles.textdes}>
                <Text style={styles.subheading}>
                  Combining yogurt with herbs, garlic, lemon juice, and spices
                  can create a tangy and light dressing option.
                </Text>
              </View>
            </View>
            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 100,
              }}
            >
              <View style={styles.bottomContainer}>
                <View style={styles.priceContainer}>
                  <Text style={styles.heading}>${price}</Text>
                </View>
                <View style={styles.priceContainer}>
                  <TouchableOpacity onPress={() => count("decrease")}>
                    <MinusSvg />
                  </TouchableOpacity>
                  <Text style={styles.quantity}>{quantity}</Text>
                  <TouchableOpacity onPress={() => count("increase")}>
                    <PlusSvg />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </ScrollView>
          <View style={{ alignItems: "center", justifyContent: "center" }}>
            <TouchableOpacity style={styles.btnContainer} onPress={addToCart}>
              <View style={styles.btnContent}>
                <PlusSvg />
                <Text style={styles.btnText}>Add To Cart</Text>
              </View>
            </TouchableOpacity>
          </View>
        </>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bodybackground,
  },
  scontainer: {
    flex: 1,
    // marginBottom: 60,
  },
  imageContainer: {
    flex: 1,
    width: width,
    height: 392,
    justifyContent: "center",
    alignItems: "center",
  },
  image: {
    width: width,
    height: 392,
    resizeMode: "cover",
    borderBottomRightRadius: 10,
    borderBottomLeftRadius: 10,
  },
  indicatorContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 10,
    marginTop: -20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.bgColor,
    marginHorizontal: 4,
  },
  textContainer: {
    justifyContent: "center",
    alignItems: "flex-start",
    borderRadius: 10,
    marginTop: 30,
    flexDirection: "column",
  },
  textdes: {
    justifyContent: "center",
    alignItems: "flex-start",
    borderRadius: 10,
    marginTop: 10,
  },
  heading: {
    fontSize: 20,
    fontWeight: "bold",
    color: colors.darkBlue,
    textAlign: "center",
  },
  subheading: {
    fontSize: 16,
    color: colors.textColor,
    textAlign: "center",
  },
  text: {
    fontSize: 54,
    color: color.warning,
    textAlign: "center",
    marginTop: 10,
    marginBottom: 10,
    fontWeight: "500",
  },
  topContainer: {
    paddingRight: Platform.OS === "ios" ? 0 : 10,
    paddingLeft: Platform.OS === "ios" ? 0 : 10,
  },
  bottomContainer: {
    paddingVertical: 10,
    width: "90%",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 20,
    flexDirection: "row",
    backgroundColor: colors.white,
    borderRadius: 10,
  },
  priceContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    padding: 10,
  },
  btnContainer: {
    position: "absolute",
    bottom: 0,
    width: "90%",
    paddingHorizontal: 20,
    paddingVertical: 10,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.primary,
    borderRadius: 10,
    marginBottom: 10,
  },
  btnContent: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  btnText: {
    fontSize: 16,
    fontWeight: "bold",
    color: colors.white,
    textAlign: "center",
    marginLeft: 10,
    paddingVertical: 10,
  },
  quantity: {
    fontSize: 20,
    fontWeight: "bold",
    color: colors.textColor,
    textAlign: "center",
    marginHorizontal: 20,
  },
  CardContainer: {
    flex: 1,
    paddingHorizontal: 10,
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
    // marginVertical: 10,
  },
  smallImageContainer: {
    flex: 1,
    paddingHorizontal: 10,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  smallImage: {
    width: 50,
    height: 50,
    borderRadius: 10,
  },
  smallImageInner: {
    marginHorizontal: 5,
  },
  someImageContainer: {
    justifyContent: "flex-start",
    alignItems: "center",
    borderRadius: 10,
    marginTop: 30,
    flexDirection: "row",
  },
});

export default ViewProductScreen;
