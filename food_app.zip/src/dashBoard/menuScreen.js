import React, { useState, useEffect, useRef } from "react";
import { View, StyleSheet, SafeAreaView, ScrollView, Dimensions, Platform, TouchableOpacity, ActivityIndicator, } from "react-native";
import { bgColor, color, colors } from "../assets/color";
import Header from "../component/elements/header";
import InputField from "../component/elements/costumInput";
import FilterSvg from "../assets/svg/FilterSvg";
import MenuCategoryCard, { SmallMenuCard } from "../component/cards/menuCategoryCard";
import CategoryCard from "../component/cards/categoryCard";
import ApiUrl from "../../navigation/Api";

const { width } = Dimensions.get("window");

const MenuScreen = ({ navigation }) => {
  const scrollViewRef = useRef();
  const [isLoading, setIsLoading] = useState(false);




  // here we go to logical part 

  const fetchData = async () => {
    try { 
      const response = await fetch(ApiUrl + '/test');
      const responseData = await response.json(); 
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await fetchData();
      setIsLoading(false);
    };
    loadData();
  }, [navigation]);
  
  return (
    <SafeAreaView style={styles.container}>
      {isLoading ? (
        <ActivityIndicator size="large" color={colors.primary} />
      ):(
        <>
      <View style={styles.topContainer}>
        <Header pageName={'Menu'} icon={true} />
      </View>
      <View style={styles.bottomContainer}>
        <View style={styles.searchContainer}>
          <InputField
            type={"search"}
            placeholder={"Search ..."}
            style={styles.inputField}
          />
          <TouchableOpacity style={styles.filter}>
            <FilterSvg />
          </TouchableOpacity>
        </View>
      </View>
      <ScrollView style={styles.scontainer}>
      <ScrollView
          ref={scrollViewRef}
          horizontal
          scrollEventThrottle={16}
          style={styles.scrollView}
        >
          <View style={styles.categorycard}>
            <TouchableOpacity >
              <SmallMenuCard />
            </TouchableOpacity> 
            <TouchableOpacity>
              <SmallMenuCard name={"Salads"} />
            </TouchableOpacity> 
            <TouchableOpacity>
              <SmallMenuCard name={"Pasta"} />
            </TouchableOpacity> 
            <TouchableOpacity>
              <SmallMenuCard name={"First courses"} />
            </TouchableOpacity> 
            <TouchableOpacity>
              <SmallMenuCard name={"Hot meals"} />
            </TouchableOpacity> 
            <TouchableOpacity>
              <SmallMenuCard name={"Fish"} />
            </TouchableOpacity>  
          </View>
        </ScrollView>
        <View style={styles.categorycard}>
          <TouchableOpacity onPress={() => navigation.navigate('CategoryScreen')}>
            <MenuCategoryCard categoryName={"Salads"} />
          </TouchableOpacity>
          <TouchableOpacity>
            <MenuCategoryCard categoryName={"Meat"} />
          </TouchableOpacity>
        </View>
        <View style={styles.categorycard}>
          <TouchableOpacity>
            <MenuCategoryCard categoryName={"Pasta"} />
          </TouchableOpacity>
          <TouchableOpacity>
            <MenuCategoryCard categoryName={"First courses"} />
          </TouchableOpacity>
        </View>
        <View style={styles.categorycard}>
          <TouchableOpacity>
            <MenuCategoryCard categoryName={"Hot meals"} />
          </TouchableOpacity>
          <TouchableOpacity>
            <MenuCategoryCard categoryName={"Fish"} />
          </TouchableOpacity>
        </View>
        <View style={styles.categorycard}>
          <TouchableOpacity>
            <MenuCategoryCard categoryName={"Hot meals"} />
          </TouchableOpacity>
          <TouchableOpacity>
            <MenuCategoryCard categoryName={"Fish"} />
          </TouchableOpacity>
        </View>
      </ScrollView>
      </>
    )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bodybackground,
    justifyContent: "center",
    paddingTop: Platform.OS === "ios" ? 0 : 0,
  },
  scontainer: {
    marginTop: Platform.OS === "ios" ? 0 : 10,
    marginBottom: 70
  },
  imageContainer: {
    width: width,
    height: 250,
    justifyContent: "center",
    alignItems: "center",
  },
  image: {
    width: width,
    height: 250,
    resizeMode: "cover",
  },
  indicatorContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 10,
    marginTop: -20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.bgColor,
    marginHorizontal: 4,
  },
  textContainer: {
    position: "absolute",
    top: 50,
    left: 0,
    right: 0,
    justifyContent: "center",
    alignItems: "flex-start",
    borderRadius: 10,
    padding: 10,
  },
  heading: {
    fontSize: 28,
    fontWeight: "bold",
    color: colors.darkBlue,
    textAlign: "center",
  },
  subheading: {
    fontSize: 14,
    color: colors.mainColor,
    textAlign: "center",
    marginTop: 5,
  },
  text: {
    fontSize: 54,
    color: color.warning,
    textAlign: "center",
    marginTop: 10,
    marginBottom: 10,
    fontWeight: "500",
  },
  topContainer: {
    paddingRight: Platform.OS === "ios" ? 0 : 10,
    paddingLeft: Platform.OS === "ios" ? 0 : 10,
    backgroundColor: 'none',
  },
  dotActive: {
    width: 6,
    height: 12,
    borderRadius: 4,
    backgroundColor: "rgba(255, 255, 255, 0.7)",
  },
  dotInactive: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.textColor,
  },
  bottomContainer: {
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 5,
    flexDirection: "row",
    paddingRight: 50,
  },
  searchContainer: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    backgroundColor: bgColor.bodybackground,
    alignItems: "center",
    width: "100%",
  },
  inputField: {
    flex: 1,
    backgroundColor: colors.white,
    borderRadius: 10,
    fontSize: 16,
  },
  bottomText: {
    fontSize: 16,
    color: colors.mainColor,
    fontWeight: "500",
  },
  productCardText: {
    fontSize: 18,
    color: colors.mainColor,
    fontWeight: "500",
  },
  CardContainer: {
    paddingHorizontal: 20,
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
  },
  bottomTextViewAll: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: "500",
  },
  categorycard: {
    paddingHorizontal: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  productCardContainer: {
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  filter: {
    padding: 10,
    height: 50,
    borderRadius: 5,
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 10,
  },
});

export default MenuScreen;
