import React, { useState, useEffect, useRef } from "react";
import { View, StyleSheet, SafeAreaView, ScrollView, Dimensions, Platform, Text, TouchableOpacity, ActivityIndicator } from "react-native";
import { bgColor, color, colors } from "../assets/color";
import Header from "../component/elements/header";
import InputField from "../component/elements/costumInput";
import FilterSvg from "../assets/svg/FilterSvg";
import MenuCategoryCard, {SmallMenuCard} from "../component/cards/menuCategoryCard";
import ProductMenuCard from "../component/cards/productMenuCard";
import ApiUrl from "../../navigation/Api";

const { width } = Dimensions.get("window");

const CategoryScreen = ({ navigation }) => {
  const scrollViewRef = useRef();
  const [isLoading, setIsLoading] = useState(false);

  // here we with the logical part
  const fetchData = async () => {
    try {
      const response = await fetch(ApiUrl + "/test");
      const responseData = await response.json();
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await fetchData();
      setIsLoading(false);
    };
    loadData();
  }, [navigation]);

  return (
    <SafeAreaView style={styles.container}>
      {isLoading ? (
        <ActivityIndicator size={"large"} color={colors.primary} />
      ) : (
        <>
          <View style={styles.topContainer}>
            <Header />
          </View>
          <View style={styles.bottomContainer}>
            <View style={styles.searchContainer}>
              <InputField
                type={"search"}
                placeholder={"Search ..."}
                style={styles.inputField}
              />
              <TouchableOpacity style={styles.filter}>
                <FilterSvg />
              </TouchableOpacity>
            </View>
          </View>
          <ScrollView style={styles.scontainer}>
            <View style={styles.smallCardContainer}>
              <ScrollView
                ref={scrollViewRef}
                horizontal
                scrollEventThrottle={16}
                style={styles.scrollView}
              >
                <View style={styles.categorycard}>
                  <TouchableOpacity>
                    <SmallMenuCard />
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <SmallMenuCard name={"Salads"} />
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <SmallMenuCard name={"Pasta"} />
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <SmallMenuCard name={"First courses"} />
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <SmallMenuCard name={"Hot meals"} />
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <SmallMenuCard name={"Fish"} />
                  </TouchableOpacity>
                </View>
              </ScrollView>
            </View>
            <View style={{ marginTop: 30 }}>
              <View style={styles.CardContainer}>
                <Text style={styles.productCardText}>Recommended for you</Text>
              </View>
              <ScrollView ref={scrollViewRef} style={styles.scrollView}>
                <View style={styles.productCardContainer}>
                  <TouchableOpacity onPress={() => navigation.navigate('ViewProduct')}>
                    <ProductMenuCard
                      id={1}
                      product={"Tandoori Chicken"}
                      calorie={"110"}
                      price={"$17.99"}
                    />
                  </TouchableOpacity>
                </View>
                <View style={styles.productCardContainer}>
                  <TouchableOpacity>
                    <ProductMenuCard
                      id={2}
                      product={"Beef Stroganoff"}
                      calorie={"110"}
                      price={"$13.49"}
                    />
                  </TouchableOpacity>
                </View>
                <View style={styles.productCardContainer}>
                  <TouchableOpacity>
                    <ProductMenuCard
                      id={3}
                      product={"Pan-Seared Duck"}
                      calorie={"110"}
                      price={"$6.99"}
                    />
                  </TouchableOpacity>
                </View>
              </ScrollView>
            </View>
          </ScrollView>
        </>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bodybackground,
    justifyContent: "center",
    alignContent: 'center',
    paddingTop: Platform.OS === "ios" ? 0 : 0,
  },
  scontainer: {
    marginTop: Platform.OS === "ios" ? 0 : 10,
  },  
  topContainer: {
    paddingRight: Platform.OS === "ios" ? 0 : 10,
    paddingLeft: Platform.OS === "ios" ? 0 : 10,
    backgroundColor: "none",
  }, 
   
  bottomContainer: {
    justifyContent: "center",
    alignItems: "center",
    marginTop: 5,
    flexDirection: "row",
    paddingRight: 50,
  },
  searchContainer: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    backgroundColor: bgColor.bodybackground,
    alignItems: "center",
    width: "100%",
  },
  inputField: {
    flex: 1,
    backgroundColor: colors.white,
    borderRadius: 10,
    fontSize: 16,
  },
  bottomText: {
    fontSize: 16,
    color: colors.mainColor,
    fontWeight: "500",
  },
  productCardText: {
    fontSize: 18,
    color: colors.mainColor,
    fontWeight: "500",
  }, 
  bottomTextViewAll: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: "500",
  },
  categorycard: {
    paddingHorizontal: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  }, 
  filter: {
    padding: 10,
    height: 50,
    borderRadius: 5,
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 10,
  }, 
  CardContainer: {
    paddingHorizontal: 20,
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
    marginBottom: 14,
  }, 
  productCardContainer: {
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
    paddingLeft: 5,
    paddingRight: 5,
  },
  ScrollCardView: {
    paddingHorizontal: 20,
    borderRadius: 10,
    marginTop: 24,
  },
   
  smallCardContainer: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  scrollView:{
    flex: 1,
    padding: 5
  }
});
export default CategoryScreen;
