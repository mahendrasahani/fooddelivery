export const colors = {
  white: "#FFFFFF",
  darkBlue: "#000000",
  textColor: "#748BA0",
  mainColor: "#0C1D2E",
  lightBlue: "#D8E7FF",
  primary: "#00B0B9",
  bodyTextColor: "#333333",
  imageBackground: "#F6F8FB",
  neonWhite: "#F6F9F9",
  transparent: "transparent",
  bgColor: "#d3d3d3",
  bodybackground: "#DFEDED",
};
// these are  the colors that i made for internal use only
export const color = {
    primary: "#00B0B9",
    secondary: "#F6F9F9",
    text: "#333333",
    border: "#d3d3d3",
    button: "#00B0B9",
    buttonText: "#FFFFFF",
    danger: "#FF0000",
    success: "#00A65A",
    warning: "#FFA500",
    light: "#F6F9F9",
    dark: "#000000",
    mainColor: '#0C1D2E',
    warning: "#FFCA40",
    percentage: '#C51406'
};
// background colors
export const bgColor = {
  imageBackground: "#F6F8FB",
  bodybackground: "#DFEDED",
  iconbgColor: "#E6F3F8",
  scrollCard: "#FFC184"
};



