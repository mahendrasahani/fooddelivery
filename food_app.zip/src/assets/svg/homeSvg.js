import * as React from "react"
const HomeSvg = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={48} height={48} {...props}>
    <path d="M39.5 43h-9a2.5 2.5 0 0 1-2.5-2.5v-9a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v9a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 6 40.5V21.413a7.502 7.502 0 0 1 2.859-5.893L23.071 4.321a1.503 1.503 0 0 1 1.857 0L39.142 15.52A7.499 7.499 0 0 1 42 21.411V40.5a2.5 2.5 0 0 1-2.5 2.5z" />
  </svg>
)
export default HomeSvg
