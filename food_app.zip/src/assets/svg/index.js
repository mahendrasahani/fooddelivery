import MapSvg from './MapSvg.js';
import KeySvg from './KeySvg.js';
import MicSvg from './MicSvg.js';
import TagSvg from './TagSvg.js';
import NewSvg from './NewSvg.js';
import CopySvg from './CopySvg.js';
import MailSvg from './MailSvg.js';
import GiftSvg from './GiftSvg.js';
import UserSvg from './UserSvg.js';
import PlusSvg from './PlusSvg.js';
import CartSvgTab from './cartSvg2.js';
import CartSvg from './CartSvg.js';
import CheckSvg from './CheckSvg.js';
// import HeartSvg from './HeartSvg';
import MinusSvg from './MinusSvg.js';
import CloseSvg from './CloseSvg.js';
import CameraSvg from './CameraSvg.js';
import NewBigSvg from './NewBigSvg.js';
import SearchSvg from './SearchSvg.js';
import EyeOffSvg from './EyeOffSvg.js';
import GoBackSvg from './GoBackSvg.js';
import GoogleSvg from './GoogleSvg.js';
import FilterSvg from './FilterSvg.js';
import ViewAllSvg from './ViewAllSvg.js';
import PlusBtnSvg from './PlusBtnSvg.js';
// import HeartBigSvg from './HeartBigSvg';
import CalendarSvg from './CalendarSvg.js';
import DishPlusSvg from './DishPlusSvg.js';
import FacebookSvg from './FacebookSvg.js';
import DishMinusSvg from './DishMinusSvg.js';
import InputCheckSvg from './InputCheckSvg.js';
import CreditCardSvg from './CreditCardSvg.js';
import ArrowRightSvg from './ArrowRightSvg.js';
import SmartphoneSvg from './SmartphoneSvg.js';
import CodeAppliedSvg from './CodeAppliedSvg.js';

export const svg = {
  KeySvg,
  NewSvg,
  MapSvg,
  MicSvg,
  TagSvg,
  GiftSvg,
  MailSvg,
  UserSvg,
  CopySvg,
  CartSvg,
  PlusSvg,
  CloseSvg,
  // HeartSvg,
  MinusSvg,
  CheckSvg,
  EyeOffSvg,
  CameraSvg,
  GoBackSvg,
  FilterSvg,
  SearchSvg,
  NewBigSvg,
  GoogleSvg,
  ViewAllSvg,
  PlusBtnSvg,
  // HeartBigSvg,
  CalendarSvg,
  DishPlusSvg,
  FacebookSvg,
  DishMinusSvg,
  InputCheckSvg,
  ArrowRightSvg,
  CreditCardSvg,
  SmartphoneSvg,
  CodeAppliedSvg,
  CartSvgTab
};
