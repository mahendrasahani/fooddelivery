import * as React from 'react';
import Svg, {G, Path, Defs, ClipPath} from 'react-native-svg';

const GoBackSvg = ({color, width, height, fillcolor}) => {
  return (
    <Svg width={width ? width : 16} height={height ? height : 16} fill='none'>
      <G clipPath='url(#a)'>
        <Path
          stroke={color ? color : 'gray'}
          strokeLinecap='round'
          strokeLinejoin='round'
          strokeWidth={2}
          d='M7 13 1 7l6-6'
        />
      </G>
      <Defs>
        <ClipPath id='a'>
          <Path fill={fillcolor ? fillcolor : 'gray'} d='M0 0h8v14H0z' />
        </ClipPath>
      </Defs>
    </Svg>
  );
};

export default GoBackSvg;
