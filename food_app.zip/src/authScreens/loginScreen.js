import React, { useState, useRef } from "react";
import { View, Text, StyleSheet, SafeAreaView, Dimensions, Platform, TouchableOpacity, TextInput, KeyboardAvoidingView, ScrollView,} from "react-native";
import { colors } from "../assets/color";
import GoogleSvg from "../assets/svg/GoogleSvg";
import FacebookSvg from "../assets/svg/FacebookSvg";
import InputField from "../component/elements/costumInput";

const { width } = Dimensions.get("window");

const TestLogin = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [eyeIcon, setEyeIcon] = useState(true);
  const [chechIcon, setChechIcon] = useState(true);
  const inp2Ref = useRef({ focus: () => {} });
  const inp3Ref = useRef({ focus: () => {} });
  ;
  const handleSubmit = () => {
    navigation.navigate('TabNavigation',{ screen:"DashBoardScreen"});
  };
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.ScrollView}>
        <KeyboardAvoidingView style={styles.center}>
          <View style={styles.scontainer}>
            <View style={styles.imageContainer}>
              <Text style={styles.heading}>Welcome Back!</Text>
              <Text style={styles.subHeading}>Sign in to continue</Text>
            </View>
            <View style={styles.textContainer}>
              <View style={styles.inputContainer}>
                <InputField
                  type="email"
                  value={email}
                  checkIcon={chechIcon}
                  innerRef={inp2Ref}
                  placeholder="jordanhebert@mail.com"
                  containerStyle={{ marginBottom: 10 }}
                  onChangeText={(text) => setEmail(text)}
                />
              </View>
            </View>
            <View style={styles.textContainer}>
              <View style={styles.inputContainer}>
                <InputField
                  type="password"
                  value={password}
                  eyeOffIcon={eyeIcon}
                  innerRef={inp3Ref}
                  placeholder="••••••••"
                  secureTextEntry={true}
                  containerStyle={{ marginBottom: 10}}
                  onChangeText={(text) => setPassword(text)}
                />
              </View>
            </View>
            <View style={styles.remember}>
              <View style={styles.rememberContainer}>
                <Text style={styles.rememberText}>Remember me</Text>
                <TouchableOpacity>
                  <Text style={styles.forgotPasswordText}>
                    Forgot password?
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
            <View style={styles.singInViewContainer}>
              <TouchableOpacity
                style={styles.signInButton}
                onPress={handleSubmit}
              >
                <Text style={styles.signInButtonText}>Sign In</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.signUpContainer}>
              <Text style={styles.signUpText}>Don't have an account?</Text>
              <TouchableOpacity>
                <Text style={styles.signUpLink}> Sign up.</Text>
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.bottomContainer}>
            <TouchableOpacity style={styles.bottomIconContainer}>
              <FacebookSvg />
            </TouchableOpacity>
            <TouchableOpacity style={styles.bottomIconContainer}>
              <GoogleSvg />
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bodybackground,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: Platform.OS === "ios" ? 0 : 67,
    paddingLeft: Platform.OS === "ios" ? 8 : 0,
    paddingRight: Platform.OS === "ios" ? 8 : 0,
  },
  center: {
    alignItems: "center",
  },
  scontainer: {
    flex: 5,
    width: width - 50,
    backgroundColor: colors.white,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 2,
    elevation: 3,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    marginTop: Platform.OS === "ios" ? 60 : 0,
  },
  bottomContainer: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
    marginBottom: Platform.OS === "ios" ? 10 : 30,
    marginTop: 10,
  },
  heading: {
    fontSize: 28,
    fontWeight: "bold",
    color: colors.heading,
    marginTop: 70,
    marginLeft: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  subHeading: {
    fontSize: 16,
    marginLeft: 23,
    textColor: colors.textColor,
    marginTop: 14,
  },
  bottomIconContainer: {
    backgroundColor: colors.white,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 2,
    elevation: 5,
    width: Platform.OS === "ios" ? 160 : 145,
    height: 80,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 10,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  textContainer: {
    flexDirection: "row",
    marginTop: 20,
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: 10,
    borderRadius: 10,
    // padding: 3,
  },

  ScrollView: { flex: 1 },

  inputContainer: {
    flexDirection: "row",
    borderRadius: 10,
    alignItems: "center",
  },

  rememberContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 10,
  },
  checkbox: {
    marginRight: 8,
  },
  rememberText: {
    flex: 1,
    fontSize: 14,
  },
  forgotPasswordText: {
    fontSize: 14,
    color: colors.primary,
  },
  signInButton: {
    backgroundColor: colors.primary,
    paddingVertical: 15,
    borderRadius: 10,
    marginVertical: 10,
    alignItems: "center",
    padding: 10,
  },
  signInButtonText: {
    color: colors.white,
    fontSize: 18,
  },
  signUpContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 10,
    marginBottom: 100,
  },
  signUpText: {
    fontSize: 14,
    color: colors.textColor,
  },
  signUpLink: {
    fontSize: 14,
    color: colors.primary,
  },
  remember: {
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 10,
    padding: 3,
    marginTop: 10,
  },
  singInViewContainer: {
    padding: 10,
  },
});

export default TestLogin;
