import React, { useState, useEffect, useRef } from "react";
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Image, ScrollView, Dimensions, Animated, Platform} from "react-native";
import { colors } from "../assets/color";

const { width, height } = Dimensions.get("window");

const OnboardingScreen = ({ navigation }) => {
  const [activeDot, setActiveDot] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scrollViewRef = useRef();

  const images = [
    {
      uri: require('../assets/images/food.jpg'),
      heading: "Embark On Culinary Adventures",
      subheading: "Embark on an exciting culinary journey with our app.",
    },
    {
      uri: require('../assets/images/food.jpg'),
      heading: "Craft Your Perfect Order",
      subheading: "Customize your cravings and place orders effortlessly.",
    },
    {
      uri: require('../assets/images/food.jpg'),
      heading: "Taste the Delivered Magic",
      subheading: "Enjoy the convenience of doorstep culinary delights.",
    },
  ];

  const dotScales = useRef(images.map(() => new Animated.Value(1))).current; 

  const handleScroll = (event) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const currentPage = Math.round(scrollPosition / width);
    setActiveDot(currentPage);
    fadeInText();
    animateDotScale(currentPage);
  };

  const fadeInText = () => {
    fadeAnim.setValue(0);
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  };

  const animateDotScale = (currentPage) => {
    dotScales.forEach((dotScale, index) => {
      Animated.spring(dotScale, {
        toValue: index === currentPage ? 1.5 : 1,
        useNativeDriver: true,
        friction: 4,
      }).start();
    });
  };

  const handleLoginClick = () => {
    if (activeDot === images.length - 1) {
      // navigation.navigate('LoginScreen');
      navigation.navigate('TabNavigation', {screen: 'DashBoardScreen'});
    } else {
      scrollViewRef.current.scrollTo({ x: (activeDot + 1) * width, animated: true });
    }
  };

  useEffect(() => {
    fadeInText();
  }, [activeDot]);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        onScroll={handleScroll}
        showsHorizontalScrollIndicator={false}
        scrollEventThrottle={16}
        style={styles.scrollView}
      >
        {images.map((image, index) => (
          <View key={index} style={styles.imageContainer}>
            {/* <Image style={styles.image} source={image.uri} /> */}
          </View>
        ))}
      </ScrollView>
      <View style={styles.overlay}>
        <View style={styles.indicatorContainer}>
          {images.map((_, index) => (
            <Animated.View key={index} style={[ styles.dot, index === activeDot ? styles.dotActive : styles.dotInactive,{
                  transform: [
                    {
                      scale: dotScales[index],
                    },
                  ],
                },
              ]}
            />
          ))}
        </View>
        <Animated.View style={[styles.textContainer, { opacity: fadeAnim }]}>
          <Text style={styles.heading}>{images[activeDot].heading}</Text>
          <Text style={styles.subheading}>
            {images[activeDot].subheading}
          </Text>
        </Animated.View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.button}
            onPress={handleLoginClick}
          >
            <Text style={styles.buttonText}>{activeDot === images.length - 1 ? "Get Started" : "Next"}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    flex: 1,
    backgroundColor: colors.bodybackground,
  },
  scrollView: {
    flex: 1,
  },
  imageContainer: {
    width: width,
    height: height,
  },
  image: { 
    width: width,
    height: height,
    resizeMode: "cover",
    position: "absolute",
  },
  overlay: {
    position: "absolute",
    top: 500,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: "center",
    alignItems: "center",
    // padding: 20,
  },
  indicatorContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.bgColor,
    marginHorizontal: 4,
  },
  dotActive: {
    width: 6,
    height: 12,
    borderRadius: 4,
    backgroundColor: colors.primary,
  },
  dotInactive: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.textColor,
  },
  textContainer: {
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.white,
    borderRadius: 10,
    padding: 20,
    // marginBottom: 20,
  },
  heading: {
    fontSize: 28,
    fontWeight: "bold",
    color: colors.darkBlue,
    textAlign: "center",
  },
  subheading: {
    fontSize: 16,
    color: colors.textColor,
    textAlign: "center",
    marginTop: 10,
  },
  buttonContainer: {
    marginTop: 20,
    paddingLeft: Platform.OS === 'ios' ? 10 : 0, 
    paddingRight: Platform.OS === 'ios' ? 10 : 0, 
  },
  button: {
    backgroundColor: colors.primary,
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonText: {
    fontSize: 18,
    color: colors.white,
    fontWeight: "bold",
  },
});

export default OnboardingScreen;
