import React, { useEffect, useRef } from "react";
import { View, StyleSheet, SafeAreaView, Image, Animated, ActivityIndicator } from "react-native";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { colors } from "../assets/color";

const FadeInView = (props) => {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.5)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 3,
        useNativeDriver: true,
      }),
    ]).start();
  }, [fadeAnim, scaleAnim]);

  return (
    <Animated.View
      style={{
        ...props.style,
        opacity: fadeAnim,
        transform: [{ scale: scaleAnim }],
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      {props.children}
    </Animated.View>
  );
};


const WelcomeScreen = ({ navigation }) => {
  useEffect(() => {
    const randomString = (length) => {
      return Math.round(
        Math.pow(36, length + 1) - Math.random() * Math.pow(36, length)
      )
        .toString(36)
        .slice(1);
    }; 

    const setToken = async () => {
      try {
        const token = await AsyncStorage.getItem('token');
        if (!token) {  
          const newToken = randomString(12);
          await AsyncStorage.setItem('token', newToken);
          console.warn("Generated Token:", newToken);
        } else {
          console.warn("Token already exists:", token);
        }
      } catch (e) {
        console.warn(e);
      }
    }

    setToken();

    const timer = setTimeout(() => {
      navigation.navigate("TabNavigation", { screen: "DashBoardScreen" });
    }, 2000);

    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.welcomeContainer}>
        <FadeInView style={styles.logoContainer}>
          <Image style={styles.logo} source={require("../assets/images/logo.png")} />
        </FadeInView>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
    alignItems: "center",
    justifyContent: "center",
  },
  welcomeContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  logoContainer: {
    width: 300,
    height: 300,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 300,
    height: 300,
    resizeMode: "contain",
  },
});

export default WelcomeScreen;
