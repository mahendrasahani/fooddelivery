import React, { useState, useRef } from "react";
import { View, Text, StyleSheet, SafeAreaView, Dimensions, Platform, TouchableOpacity, KeyboardAvoidingView, ScrollView, } from "react-native";
import { colors } from "../assets/color";
import GoogleSvg from "../assets/svg/GoogleSvg";
import FacebookSvg from "../assets/svg/FacebookSvg"; 
import InputField from "../component/elements/costumInput";

const { width } = Dimensions.get("window");

const TestLogin = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [userName, setUserName] = useState("");

  const [confirmPassword, setConfirmPassword] = useState("");

  const handleSubmit = () => {
    console.warn(email, password);
    navigation.navigate("registerScreen");
  };

  const inp1Ref = useRef({ focus: () => {} });
  const inp2Ref = useRef({ focus: () => {} });
  const inp3Ref = useRef({ focus: () => {} });
  const inp4Ref = useRef({ focus: () => {} });
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.ScrollView}>
        <KeyboardAvoidingView style={styles.center}>
          <View style={styles.scontainer}>
            <View style={styles.imageContainer}>
              <Text style={styles.heading}>Sign up</Text>
              <Text style={styles.subHeading}>Sign up to continue</Text>
            </View>
            <View style={styles.textContainer}>
              <View style={styles.inputContainer}>
                <InputField
                  type="username"
                  innerRef={inp1Ref}
                  value={userName}
                  placeholder="Jordan Hebert"
                  containerStyle={{ marginBottom: 14 }}
                  onChangeText={(text) => setUserName(text)}
                />
              </View>
            </View>
            <View style={styles.textContainer}>
              <View style={styles.inputContainer}>
                <InputField
                  type="email"
                  value={email}
                  checkIcon={false}
                  innerRef={inp2Ref}
                  placeholder="jordanhebert@mail.com"
                  containerStyle={{ marginBottom: 14 }}
                  onChangeText={(text) => setEmail(text)}
                />
              </View>
            </View>
            <View style={styles.textContainer}>
              <View style={styles.inputContainer}>
                <InputField
                  type="password"
                  value={password}
                  eyeOffIcon={true}
                  innerRef={inp3Ref}
                  placeholder="••••••••"
                  secureTextEntry={true}
                  containerStyle={{ marginBottom: 14 }}
                  onChangeText={(text) => setPassword(text)}
                />
              </View>
            </View>
            <View style={styles.textContainer}>
              <View style={styles.inputContainer}>
                <InputField
                  type="password"
                  eyeOffIcon={true}
                  innerRef={inp4Ref}
                  value={confirmPassword}
                  placeholder="••••••••"
                  secureTextEntry={true}
                  containerStyle={{ marginBottom: 14 }}
                  onChangeText={(text) => setConfirmPassword(text)}
                />
              </View>
            </View>
            <View style={styles.singInViewContainer}>
              <TouchableOpacity
                style={styles.signInButton}
                onPress={handleSubmit}
              >
                <Text style={styles.signInButtonText}>Sign In</Text>
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.bottomContainer}>
            <TouchableOpacity style={styles.bottomIconContainer}>
              <FacebookSvg />
            </TouchableOpacity>
            <TouchableOpacity style={styles.bottomIconContainer}>
              <GoogleSvg />
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bodybackground,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: Platform.OS === "ios" ? 0 : 67,
    paddingLeft: Platform.OS === "ios" ? 8 : 0,
    paddingRight: Platform.OS === "ios" ? 8 : 0,
  },
  center: {
    alignItems: "center",
  },
  scontainer: {
    flex: 5,
    width: width - 50,
    backgroundColor: colors.white,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 2,
    elevation: 3,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    marginTop: Platform.OS === "ios" ? 60 : 0,
  },
  bottomContainer: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
    marginBottom: Platform.OS === "ios" ? 10 : 30,
    marginTop: 10,
  },
  heading: {
    fontSize: 28,
    fontWeight: "bold",
    color: colors.heading,
    marginTop: 70,
    marginLeft: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  subHeading: {
    fontSize: 16,
    marginLeft: 23,
    textColor: colors.textColor,
    marginTop: 14,
  },
  bottomIconContainer: {
    backgroundColor: colors.white,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 2,
    elevation: 5,
    width: Platform.OS === "ios" ? 160 : 145,
    height: 80,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 10,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  textContainer: {
    flexDirection: "row",
    marginTop: 10,
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: 10,
    borderRadius: 10,
    padding: 3,
  },
  icon: {
    backgroundColor: colors.primary,
    width: 50,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
    borderColor: "#e0e0e0",
    borderWidth: 1,
  },
  input: {
    flex: 1,
    height: 50,
    marginLeft: 10,
  },
  ScrollView: { flex: 1 },
  inputContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    // backgroundColor: "#e0e0e0",
    borderRadius: 10,
    alignItems: "center",
  },
  iconLeft: {
    borderRadius: 10,
    borderColor: "#e0e0e0",
    borderWidth: 1,
    marginRight: 8,
  },
  rememberContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 10,
  },
  checkbox: {
    marginRight: 8,
  },
  rememberText: {
    flex: 1,
    fontSize: 14,
  },
  forgotPasswordText: {
    fontSize: 14,
    color: colors.primary,
  },
  signInButton: {
    backgroundColor: colors.primary,
    paddingVertical: 15,
    borderRadius: 10,
    marginVertical: 10,
    alignItems: "center",
    padding: 10,
  },
  signInButtonText: {
    color: colors.white,
    fontSize: 18,
  },
  signUpContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 10,
    marginBottom: 100,
  },
  signUpText: {
    fontSize: 14,
    color: colors.textColor,
  },
  signUpLink: {
    fontSize: 14,
    color: colors.primary,
  },
  remember: {
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 10,
    padding: 3,
    marginTop: 10,
  },
  singInViewContainer: {
    padding: 10,
    marginBottom: 40,
  },
});

export default TestLogin;
