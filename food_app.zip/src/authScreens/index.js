import LoginScreen from "./loginScreen";
import RegisterScreen from "./registerScreen";
import WelcomeScreen from "./welcomScreen";

export default {LoginScreen, RegisterScreen, WelcomeScreen}