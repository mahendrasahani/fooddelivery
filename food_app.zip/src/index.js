import LoginScreen from "./authScreens/loginScreen";
import RegisterScreen from "./authScreens/registerScreen";
import WelcomeScreen from "./authScreens/welcomScreen";

export default {LoginScreen, RegisterScreen, WelcomeScreen}